import json, os, boto3, datetime

def handler(event, context):
    bucket = os.environ["TARGET_BUCKET"]
    key    = f"deposits/{datetime.datetime.utcnow().isoformat()}.json"
    boto3.client("s3").put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps({"status": "placeholder", "event": event}),
        ContentType="application/json",
    )
    return {"statusCode": 200, "key": key}
